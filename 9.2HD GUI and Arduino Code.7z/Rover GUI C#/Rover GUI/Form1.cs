﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace Rover_GUI
{
    public partial class Form1 : Form
    {
        private SerialPort myPort;
        public Form1()
        {
            InitializeComponent();
            init();
        }

        private void Forward_btn_Click(object sender, EventArgs e)
        {
            myPort.WriteLine("1");
            Forward_btn.Enabled = false;
            Backward_btn.Enabled = true;
            Right_btn.Enabled = true;
            Left_btn.Enabled = true;
            button1.Enabled = true;
        }

        private void Backward_btn_Click(object sender, EventArgs e)
        {
            myPort.WriteLine("2");
            Forward_btn.Enabled = true;
            Backward_btn.Enabled = false;
            Right_btn.Enabled = true;
            Left_btn.Enabled = true;
            button1.Enabled = true;
        }

        private void Right_btn_Click(object sender, EventArgs e)
        {
            myPort.WriteLine("3");
            Forward_btn.Enabled = true;
            Backward_btn.Enabled = true;
            Right_btn.Enabled = false;
            Left_btn.Enabled = true;
            button1.Enabled = true;
        }

        private void Left_btn_Click(object sender, EventArgs e)
        {
            myPort.WriteLine("4");
            Forward_btn.Enabled = true;
            Backward_btn.Enabled = true;
            Right_btn.Enabled = true;
            Left_btn.Enabled = false;
            button1.Enabled = true;
        }

        private void button1_Click(object sender, EventArgs e) //Stop
        {
            myPort.WriteLine("0");
            Forward_btn.Enabled = true;
            Backward_btn.Enabled = true;
            Right_btn.Enabled = true;
            Left_btn.Enabled = true;
            button1.Enabled = false;
        }

        private void init()
        {
            try
            {
                myPort = new SerialPort();
                myPort.BaudRate = 9600;
                myPort.PortName = "COM4";
                myPort.Open();
            }
            catch(Exception)
            {
                MessageBox.Show("Error!");
            }

            Forward_btn.Enabled = false;
            Backward_btn.Enabled = false;
            Right_btn.Enabled = false;
            Left_btn.Enabled = false;
            button1.Enabled = true;
        }
    }
}
