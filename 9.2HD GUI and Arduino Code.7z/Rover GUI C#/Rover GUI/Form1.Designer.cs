﻿namespace Rover_GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.Forward_btn = new System.Windows.Forms.Button();
            this.Left_btn = new System.Windows.Forms.Button();
            this.Backward_btn = new System.Windows.Forms.Button();
            this.Right_btn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(341, 168);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(99, 93);
            this.button1.TabIndex = 0;
            this.button1.Text = "STOP";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Forward_btn
            // 
            this.Forward_btn.BackColor = System.Drawing.Color.Lime;
            this.Forward_btn.Location = new System.Drawing.Point(341, 69);
            this.Forward_btn.Name = "Forward_btn";
            this.Forward_btn.Size = new System.Drawing.Size(99, 93);
            this.Forward_btn.TabIndex = 1;
            this.Forward_btn.Text = "FORWARD";
            this.Forward_btn.UseVisualStyleBackColor = false;
            this.Forward_btn.Click += new System.EventHandler(this.Forward_btn_Click);
            // 
            // Left_btn
            // 
            this.Left_btn.BackColor = System.Drawing.Color.Lime;
            this.Left_btn.Location = new System.Drawing.Point(236, 168);
            this.Left_btn.Name = "Left_btn";
            this.Left_btn.Size = new System.Drawing.Size(99, 93);
            this.Left_btn.TabIndex = 2;
            this.Left_btn.Text = "LEFT";
            this.Left_btn.UseVisualStyleBackColor = false;
            this.Left_btn.Click += new System.EventHandler(this.Left_btn_Click);
            // 
            // Backward_btn
            // 
            this.Backward_btn.BackColor = System.Drawing.Color.Lime;
            this.Backward_btn.Location = new System.Drawing.Point(341, 267);
            this.Backward_btn.Name = "Backward_btn";
            this.Backward_btn.Size = new System.Drawing.Size(99, 93);
            this.Backward_btn.TabIndex = 3;
            this.Backward_btn.Text = "BACKWARD";
            this.Backward_btn.UseVisualStyleBackColor = false;
            this.Backward_btn.Click += new System.EventHandler(this.Backward_btn_Click);
            // 
            // Right_btn
            // 
            this.Right_btn.BackColor = System.Drawing.Color.Lime;
            this.Right_btn.Location = new System.Drawing.Point(446, 168);
            this.Right_btn.Name = "Right_btn";
            this.Right_btn.Size = new System.Drawing.Size(99, 93);
            this.Right_btn.TabIndex = 4;
            this.Right_btn.Text = "RIGHT";
            this.Right_btn.UseVisualStyleBackColor = false;
            this.Right_btn.Click += new System.EventHandler(this.Right_btn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Right_btn);
            this.Controls.Add(this.Backward_btn);
            this.Controls.Add(this.Left_btn);
            this.Controls.Add(this.Forward_btn);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Forward_btn;
        private System.Windows.Forms.Button Left_btn;
        private System.Windows.Forms.Button Backward_btn;
        private System.Windows.Forms.Button Right_btn;
    }
}

